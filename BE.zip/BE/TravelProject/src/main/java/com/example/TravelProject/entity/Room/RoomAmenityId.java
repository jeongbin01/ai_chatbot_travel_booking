package com.example.TravelProject.entity.room;

import java.io.Serializable;

public class RoomAmenityId implements Serializable {
    private Long roomTypeId;
    private Long amenityId;
    // equals, hashCode
}

