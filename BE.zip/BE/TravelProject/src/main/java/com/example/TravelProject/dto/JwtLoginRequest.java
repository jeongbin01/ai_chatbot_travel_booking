package com.example.TravelProject.dto;

import lombok.Getter;

@Getter
public class JwtLoginRequest {
    private String username;
    private String password;
}
